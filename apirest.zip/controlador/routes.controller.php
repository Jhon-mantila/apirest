<?php

class RoutesController{

    //Rutas principal
    public function index(){
        include "rutas/routes.php";
    }
}

?>